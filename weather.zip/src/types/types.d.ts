export interface ICData{
    capital: string,
    population: number,
    latlng: number[],
    flag: string
}

export interface IWeather{
    tempereture: number,
    weather_icon: string,
    wind_speed: number,
    precip: number
}